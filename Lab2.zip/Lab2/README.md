# Machine Learning Workflow Lab


## Dataset Information

The notebook utilizes the `car.data` dataset. The data is loaded with the following column headers:
- `buying`
- `maint`
- `doors`
- `persons`
- `lug_boot`
- `safety`
- `class`

## Notebook Overview

The notebook performs the following steps:

1.  **Data Loading**: Loads the dataset using `pandas`.
2.  **Exploratory Data Analysis (EDA)**:
    - Displays the shape of the dataset.
    - Previews the first few rows of the data.
    - Checks column names and data types.
3.  **Methodology**: Visualizes the workflow process using a Mermaid diagram.


